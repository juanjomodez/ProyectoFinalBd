package com.proyecto.backend_club_de_lectura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendClubDeLecturaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendClubDeLecturaApplication.class, args);
	}

}
