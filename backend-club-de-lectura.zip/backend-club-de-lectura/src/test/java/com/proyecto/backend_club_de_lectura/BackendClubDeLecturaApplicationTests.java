package com.proyecto.backend_club_de_lectura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendClubDeLecturaApplicationTests {

	@Test
	void contextLoads() {
	}

}
